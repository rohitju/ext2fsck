#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<fcntl.h>
#include <inttypes.h>

static int device;
const unsigned int sector_size_bytes = 512;

void print_partition_details(int part_number);
void read_sectors (int64_t start_sector, unsigned int num_sectors, void *into);

int main (int argc, char **argv){
    int part_number;
    char *image_path;
    int c;
    while ((c = getopt (argc, argv, "p:i:")) != -1) {
        switch (c)
            {
                case 'p':
                    part_number = atoi(optarg);
                    if(part_number == 0) {
                        fprintf(stderr, "Option 'p' requires an integer argument\n. Will exit now...");
                        exit(-1);
                    }
                    break;
                case 'i':
                    image_path = optarg;
                    strncpy(image_path, optarg, 100);
                    break;
                case '?':
                    if (optopt == 'p' || optopt == 'i')
                        fprintf(stderr, "Argument not given for option %c\n", optopt);
                    else if (isprint(optopt))
                        fprintf (stderr, "Unknown option `-%c'.\n", optopt);
                    else
                        fprintf (stderr, "Unknown option character `\\x%x'.\n", optopt);
                    exit(-1);
                    break;
                default:
                    break;
            }
    }


    if ((device = open(image_path, O_RDWR)) == -1) {
        perror("Could not open device file");
        exit(-1);
    } 

    print_partition_details(part_number);

}

/* read_sectors: read a specified number of sectors into a buffer.
 *
 * inputs:
 *   int64 start_sector: the starting sector number to read.
 *                       sector numbering starts with 0.
 *   int numsectors: the number of sectors to read.  must be >= 1.
 *   int device [GLOBAL]: the disk from which to read.
 *
 * outputs:
 *   void *into: the requested number of sectors are copied into here.
 *
 * modifies:
 *   void *into
 */
void read_sectors (int64_t start_sector, unsigned int num_sectors, void *into)
{
    ssize_t ret;
    int64_t lret;
    int64_t sector_offset;
    ssize_t bytes_to_read;

    sector_offset = start_sector * sector_size_bytes;

    if ((lret = lseek64(device, sector_offset, SEEK_SET)) != sector_offset) {
        fprintf(stderr, "Seek to position %"PRId64" failed: "
                "returned %"PRId64"\n", sector_offset, lret);
        exit(-1);
    }

    bytes_to_read = sector_size_bytes * num_sectors;

    if ((ret = read(device, into, bytes_to_read)) != bytes_to_read) {
        fprintf(stderr, "Read sector %"PRId64" length %d failed: "
                "returned %"PRId64"\n", start_sector, num_sectors, ret);
        exit(-1);
    }
}

unsigned char get_partition_type (unsigned char *sector, int part_num) {
    return sector[446 + (part_num) * 16 + 4];
}

void print_partition_details(int part_number){
    if (part_number < 0) {
        printf("-1\n");
        return;
    }
    int curr_part_number = 0;
    int curr_sector = 0; 
    unsigned char buf[sector_size_bytes];
    int ebr_start_lba = 0;
    int prev_ebr_lba = 0;
    int prev_sector = 0;
    int part_start;
    int part_length;
    unsigned char part_type;

    while (curr_part_number <= part_number) {
        read_sectors(curr_sector, 1, buf);
        prev_sector = curr_sector;
        int i;
        for (i = 0; i < 4; i++){
            part_type = get_partition_type(buf, i);

            //Check if partition 2 is not EBR, then break
            if (curr_sector != 0 && i == 1 && part_type != 0x05)
                break;
            if (!(part_type == 0x05 && curr_sector != 0)){  //Increment counter if not EBR in sector 0
                curr_part_number++;
                if (curr_part_number > part_number)
                    break;
            }
            if (curr_part_number == part_number) {
                part_start = (prev_sector == 0 ? 0 : curr_sector) + get_partition_start(buf, i);
                part_length = get_partition_length(buf, i);
                printf("0x%02X %d %d\n", part_type, part_start, part_length);
                exit(0);
            }
            if (part_type == 0x05 && curr_sector == 0) {
                ebr_start_lba = get_partition_start(buf, i);
                prev_ebr_lba = ebr_start_lba;
                prev_sector = curr_sector;
                curr_sector = ebr_start_lba;
            }
            else if (part_type == 0x05 && curr_sector != 0) {
                prev_ebr_lba = get_partition_start(buf, i);
                prev_sector = curr_sector;
                curr_sector = ebr_start_lba + prev_ebr_lba;
                break;
            }
        }
        if (curr_sector == prev_sector)
            break;
    } 
    if (curr_part_number < part_number)
        printf("-1\n");
}

//Assume least significant byte in buf[3]
int convert_bytes_to_uint32 (unsigned char *buf) {
    return buf[3] + (buf[2] << 8) + (buf[1] << 16) + (buf[0] << 24);
}

int get_partition_length (unsigned char *sector, int part_num) {
    unsigned char buf[4];
    int i;
    int byteOffset = 446 + (part_num) * 16 + 15;
    for (i = 0; i < 4; i++){
        buf[i] = sector[byteOffset--];
    }
    return convert_bytes_to_uint32(buf);
}

int get_partition_start (unsigned char *sector, int part_num) {
    unsigned char buf[4];
    int i;
    int byteOffset = 446 + (part_num) * 16 + 11;
    for (i = 0; i < 4; i++){
        buf[i] = sector[byteOffset--];
    }
    return convert_bytes_to_uint32(buf);
}

